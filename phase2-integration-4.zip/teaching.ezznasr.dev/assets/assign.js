/* ==========================================================================
   assign.js — assignment submission engine for teaching.ezznasr.dev.

   Reads data-subject / data-lesson / data-mode off the mount container.
   data-mode is one of: "text" | "url" | "file" | "both" | "graded".

   Every submission is queued into localStorage ("teaching_pending_submissions",
   same bucket quiz.js uses) as a durability fallback, AND — when the Drive
   bridge endpoint below is configured — POSTed straight to the Apps Script
   Web App, which saves it into your Drive folder. Students only ever talk
   to this site and the Web App URL; they never see drive.google.com.

   DRIVE_ENDPOINT is baked in at build time by app_main.py's "Sync site
   assets" action (see modules/common.py sync_site_assets). If it's empty,
   url/file/both modes will queue locally but tell the student submission
   isn't fully wired up yet — set it up in the Quiz Maker app first.

   Login (v2): the free-typed name/email fields are gone. auth.js (must be
   loaded first — see assignment.html) gates entry with phone+password and
   hands back { student_id, student_name }, which now identifies every
   submission instead.

   Graded mode (new): a fifth submission type, alongside text/url/file/both
   rather than replacing them. Assignment Maker writes a
   <script type="application/json" id="assign-questions"> block into
   assignment.html (same convention as quiz.html's #quiz-data) containing
   { items: [...] } — each item is "mcq", "truefalse", or "match". Every
   item renders as a question with one or more <select> dropdowns in front
   of it (deliberately different from quiz.js's click-to-answer buttons —
   this mirrors how these question types are usually laid out on paper: a
   dropdown per line). Grading is entirely deterministic and happens
   client-side the instant the student submits — no server round trip
   needed to know the score, though the score is still POSTed up alongside
   the answer breakdown so it shows in the Submissions sheet/dashboard.
   ========================================================================== */

(function () {
  "use strict";

  var QUEUE_KEY = "teaching_pending_submissions";
  // Mirrors quiz.js's "last attempt" memory — lets other code on the page
  // (the video-lock script in assignment.html) know this lesson's
  // assignment has been submitted at least once, without re-deriving it
  // from the transient upload queue (which gets drained once synced).
  var LAST_SUBMISSION_PREFIX = "teaching_last_submission:";
  var DRIVE_ENDPOINT = "https://script.google.com/macros/s/AKfycbzpyJWSI9aRseig5JBmydzo34ogfNYv9qQH1HrzIUGcgETF1rk4pE8qO8j7Hp3FrVjCvw/exec";
  var MAX_FILE_BYTES = 15 * 1024 * 1024; // 15MB — keep well under Apps Script's request-size ceiling
  function el(tag, attrs, children) {
    var node = document.createElement(tag);
    attrs = attrs || {};
    Object.keys(attrs).forEach(function (k) {
      if (k === "class") node.className = attrs[k];
      else if (k === "html") node.innerHTML = attrs[k];
      else node.setAttribute(k, attrs[k]);
    });
    (children || []).forEach(function (c) {
      // null/undefined/false are skipped; DOM nodes pass through; anything else
      // (a number such as 0 or 123 that a Sheet cell turned into) is shown as
      // text instead of throwing inside appendChild.
      if (c === null || c === undefined || c === false) return;
      node.appendChild(
        typeof c === "object" && typeof c.nodeType === "number" ? c : document.createTextNode(String(c))
      );
    });
    return node;
  }

  function isoDate(d) {
    return d.toISOString().slice(0, 10);
  }

  function queueSubmission(payload) {
    try {
      var existing = JSON.parse(localStorage.getItem(QUEUE_KEY) || "[]");
      existing.push(payload);
      localStorage.setItem(QUEUE_KEY, JSON.stringify(existing));
      return true;
    } catch (e) {
      return false;
    }
  }

  function saveLastSubmission(subject, lesson, record) {
    try {
      localStorage.setItem(LAST_SUBMISSION_PREFIX + (subject || "?") + ":" + (lesson || "?"),
                            JSON.stringify(record));
    } catch (e) {
      /* localStorage unavailable — nothing to recover here */
    }
  }

  function fileToBase64(file) {
    return new Promise(function (resolve, reject) {
      var reader = new FileReader();
      reader.onload = function () {
        // reader.result is "data:<mime>;base64,<data>" — strip the prefix
        var result = String(reader.result || "");
        var comma = result.indexOf(",");
        resolve(comma >= 0 ? result.slice(comma + 1) : result);
      };
      reader.onerror = function () { reject(new Error("Could not read the file.")); };
      reader.readAsDataURL(file);
    });
  }

  // Unique id per submission. The server refuses a second row with the same
  // client_id, so re-sending the same record (auto-retry below, the
  // "Retry sending" button, or a double-click) can never create a duplicate.
  function newId() {
    try { if (window.crypto && window.crypto.randomUUID) return window.crypto.randomUUID(); } catch (e) { /* fall through */ }
    return "c" + Date.now().toString(36) + Math.random().toString(36).slice(2, 12);
  }

  // Retries (same payload, same client_id) when the request never got a
  // usable answer: network drop / timeout, or Apps Script returning an
  // HTML page instead of JSON. Safe because the server dedupes on
  // client_id. A real server-side rejection ({ok:false}) is NOT retried —
  // with one exception: {ok:false, retryable:true} means the server's lock
  // was busy (a whole class saving at once). That is waited out for longer,
  // spread randomly so students don't all retry in the same second, and
  // onBusy() lets the page say "still saving" instead of showing an error.
  var RETRY_DELAYS = [1500, 4000];
  var BUSY_DELAYS = [2000, 5000, 10000, 20000];
  function postToDrive(payload, onBusy, tries) {
    tries = tries || { net: 0, busy: 0 };
    if (!DRIVE_ENDPOINT) return Promise.reject(new Error("not-configured"));
    function resendAfter(ms) {
      return new Promise(function (resolve) { setTimeout(resolve, ms); })
        .then(function () { return postToDrive(payload, onBusy, tries); });
    }
    function again(reason) {
      if (tries.net >= RETRY_DELAYS.length) throw reason;
      return resendAfter(RETRY_DELAYS[tries.net++]);
    }
    function busyAgain(reason) {
      if (tries.busy >= BUSY_DELAYS.length) throw reason;
      if (onBusy) { try { onBusy(); } catch (e) { /* display only */ } }
      return resendAfter(BUSY_DELAYS[tries.busy++] * (0.75 + Math.random() * 0.5));
    }
    return fetch(DRIVE_ENDPOINT, {
      method: "POST",
      headers: { "Content-Type": "text/plain;charset=utf-8" },
      body: JSON.stringify(payload),
    })
      .then(function (resp) { return resp.text(); })
      .then(function (raw) { return { raw: raw }; }, function () { return { netFail: true }; })
      .then(function (r) {
        if (r.netFail) return again(new Error("Couldn't reach the server."));
        var data;
        try {
          data = JSON.parse(r.raw);
        } catch (e) {
          return again(new Error("The server sent back something unexpected. Please try again."));
        }
        if (data && data.ok === false && data.retryable) {
          return busyAgain(new Error(data.error || "The server is busy right now. Please try again."));
        }
        if (!data || !data.ok) throw new Error((data && data.error) || "Drive bridge rejected the request.");
        return data;
      });
  }

  function loadGradedQuestions() {
    var node = document.querySelector("#assign-questions");
    if (!node) return null;
    try {
      var data = JSON.parse(node.textContent);
      return (data && Array.isArray(data.items)) ? data : null;
    } catch (e) {
      return null;
    }
  }

  // First option is always the unanswered placeholder (value ""), so a
  // student can't accidentally submit with a dropdown left at its default
  // — onSubmit below checks for value === "" to catch that.
  function buildSelect(options, placeholder) {
    var sel = el("select", { class: "qz-select" }, [
      el("option", { value: "" }, [placeholder || "Choose\u2026"]),
    ].concat(options.map(function (opt) { return el("option", { value: opt }, [opt]); })));
    return sel;
  }

  // Photo answers ("written" items). capture.js is loaded on demand so assignment
  // pages generated before it existed keep working untouched.
  function loadCapture() {
    if (window.TeachingCapture) return Promise.resolve(window.TeachingCapture);
    return new Promise(function (resolve, reject) {
      var s = document.createElement("script");
      s.src = "/assets/capture.js?v=1";
      s.onload = function () { window.TeachingCapture ? resolve(window.TeachingCapture) : reject(new Error("camera tools missing")); };
      s.onerror = function () { reject(new Error("Couldn't load the camera tools. Check your connection and refresh the page.")); };
      document.head.appendChild(s);
    });
  }

  function mount(rootSelector) {
    var root = document.querySelector(rootSelector);
    if (!root) return;

    var subject = root.getAttribute("data-subject") || null;
    var lesson = root.getAttribute("data-lesson") || null;
    var mode = root.getAttribute("data-mode") || "text";

    if (!window.AuthEngine) {
      root.textContent = "Sign-in couldn't load. Refresh the page to try again.";
      return;
    }

    window.AuthEngine.mount(rootSelector, function (session) {
      if (mode === "graded") startGraded(session);
      else startAssignment(session);
    });

    function startGraded(session) {
      var data = loadGradedQuestions();
      if (!data || !data.items.length) {
        root.innerHTML = "";
        root.appendChild(el("div", { class: "qz-error" }, [
          "This assignment doesn't have any graded questions configured yet.",
        ]));
        return;
      }

      var state = { submitted: false, score: 0, total: 0, answers: [], record: null, syncStatus: null, widgets: {}, photoError: "" };
      render();

      function render() {
        root.innerHTML = "";
        if (state.submitted) { renderResult(); return; }
        renderForm();
      }

      function renderForm() {
        var errorMsg = el("div", { class: "qz-error" });
        var itemsWrap = el("div", {});
        var entries = []; // { item, select } for mcq/truefalse, { item, rowSelects } for match

        data.items.forEach(function (item) {
          var block = el("div", { class: "qz-graded-item" }, [
            el("p", { class: "qz-question", html: item.prompt }),
          ]);

          if (item.type === "mcq") {
            if (item.correct.length > 1) {
              var checks = item.options.map(function (opt) {
                var cb = el("input", { type: "checkbox", value: opt });
                var label = el("label", { class: "qz-graded-check" }, [cb, " " + opt]);
                return { opt: opt, cb: cb, label: label };
              });
              checks.forEach(function (c) { block.appendChild(el("div", { class: "qz-graded-row" }, [c.label])); });
              entries.push({ item: item, checks: checks });
            } else {
              var sel = buildSelect(item.options);
              block.appendChild(el("div", { class: "qz-graded-row" }, [sel]));
              entries.push({ item: item, select: sel });
            }
          } else if (item.type === "truefalse") {
            var sel = buildSelect(["True", "False"]);
            block.appendChild(el("div", { class: "qz-graded-row" }, [sel]));
            entries.push({ item: item, select: sel });
          } else if (item.type === "written") {
            // Answered on paper: the student photographs it. Not auto-graded.
            block.appendChild(el("p", { class: "qz-lede" }, ["Write your answer on paper, then take a clear photo of it" +
              (item.max_marks ? " (" + item.max_marks + " mark" + (item.max_marks > 1 ? "s" : "") + ")" : "") + "."]));
            var slot = el("div", {}, [el("p", { class: "qz-progress" }, ["Loading camera tools\u2026"])]);
            block.appendChild(slot);
            (function (itm, holder) {
              loadCapture().then(function (cap) {
                var w = cap.createWidget({ key: "teaching_hw_draft:" + session.student_id + ":" + (lesson || "") + ":" + itm.id, max: itm.max_images || 3 });
                state.widgets[itm.id] = w; holder.innerHTML = ""; holder.appendChild(w.el);
              }, function (e) { holder.innerHTML = ""; holder.appendChild(el("div", { class: "qz-error" }, [e.message])); });
            })(item, slot);
            entries.push({ item: item, written: true });
          } else if (item.type === "match") {
            var rowSelects = [];
            (item.rows || []).forEach(function (row) {
              var rsel = buildSelect(item.options);
              rowSelects.push(rsel);
              block.appendChild(el("div", { class: "qz-graded-row" }, [
                el("span", { class: "qz-graded-row__label" }, [row.label]),
                rsel,
              ]));
            });
            entries.push({ item: item, rowSelects: rowSelects });
          }

          itemsWrap.appendChild(block);
        });

        var submitBtn = el("button", { class: "qz-next", type: "button" }, ["Submit assignment \u2192"]);
        submitBtn.addEventListener("click", function () { onSubmit(); });

        function onSubmit() {
          var incomplete = entries.some(function (e) {
            if (e.written) return false;                      // photos are optional to attach, never block
            if (e.checks) return !e.checks.some(function (c) { return c.cb.checked; });
            return e.select ? e.select.value === "" : e.rowSelects.some(function (rs) { return rs.value === ""; });
          });
          if (incomplete) {
            errorMsg.textContent = "Please answer every question before submitting.";
            return;
          }
          submitBtn.disabled = true;
          grade(entries);
        }

        var card = el("div", { class: "qz-card frame" }, [
          el("span", { class: "tick-br" }),
          el("span", { class: "tick-bl" }),
          el("div", { class: "qz-verdict" }, [
            el("span", { class: "qz-verdict__explain" }, ["Signed in as " + session.student_name]),
          ]),
          itemsWrap,
          errorMsg,
          el("div", { class: "qz-actions" }, [submitBtn]),
        ]);
        root.appendChild(card);
      }

      function grade(entries) {
        var score = 0, total = 0, answers = [];

        entries.forEach(function (e) {
          var item = e.item;
          if (e.written) {
            var w = state.widgets[item.id], n = w ? w.count() : 0, max = Math.max(1, Math.floor(Number(item.max_marks)) || 1);
            total += max;
            answers.push({
              id: item.id, type: "written", prompt: item.prompt,
              chosen: n ? "[" + n + " photo" + (n > 1 ? "s" : "") + "]" : "", correct_answer: "", is_correct: false,
              pending: n > 0, max: max, image_count: n,
              chapter: (typeof item.chapter !== "undefined") ? item.chapter : null,
            });
          } else if (item.type === "match") {
            item.rows.forEach(function (row, i) {
              total++;
              var chosen = e.rowSelects[i].value;
              var isCorrect = chosen === row.correct;
              if (isCorrect) score++;
              answers.push({
                id: item.id + ":" + i, type: "match", prompt: item.prompt + " \u2014 " + row.label,
                chosen: chosen, correct_answer: row.correct, is_correct: isCorrect,
                chapter: (typeof item.chapter !== "undefined") ? item.chapter : null,
              });
            });
          } else if (item.type === "mcq" && e.checks) {
            total++;
            var chosenOpts = e.checks.filter(function (c) { return c.cb.checked; }).map(function (c) { return c.opt; });
            var correctOpts = item.correct.map(function (i) { return item.options[i]; });
            var isCorrect = chosenOpts.length === correctOpts.length &&
              chosenOpts.slice().sort().every(function (v, i) { return v === correctOpts.slice().sort()[i]; });
            if (isCorrect) score++;
            answers.push({
              id: item.id, type: "mcq", prompt: item.prompt,
              chosen: chosenOpts.join(", "), correct_answer: correctOpts.join(", "), is_correct: isCorrect,
              chapter: (typeof item.chapter !== "undefined") ? item.chapter : null,
            });
          } else {
            total++;
            var chosen = e.select.value;
            var correctAnswer = item.type === "truefalse" ? (item.correct ? "True" : "False") : item.options[item.correct[0]];
            var isCorrect = chosen === correctAnswer;
            if (isCorrect) score++;
            answers.push({
              id: item.id, type: item.type, prompt: item.prompt,
              chosen: chosen, correct_answer: correctAnswer, is_correct: isCorrect,
              chapter: (typeof item.chapter !== "undefined") ? item.chapter : null,
            });
          }
        });

        state.score = score;
        state.total = total;
        state.answers = answers;
        state.submitted = true;

        var now = new Date();
        var record = {
          type: "assignment",
          client_id: newId(),
          subject: subject,
          lesson: lesson,
          student_id: session.student_id,
          name: session.student_name,
          email: null,
          date: isoDate(now),
          submitted_time: now.toISOString(),
          submission_type: "graded",
          score: score,
          total: total,
          answers: answers,
        };

        queueSubmission(record);
        saveLastSubmission(subject, lesson, record);
        state.record = record;
        sendRecord();
      }

      // Photo answers go up first, under this submission's client_id, so the
      // teacher's grading queue can pair them with it. Already-sent photos are
      // skipped, and the server ignores a re-sent one, so retrying is safe.
      function uploadPhotos() {
        var written = state.record.answers.filter(function (a) { return a.type === "written" && state.widgets[a.id]; });
        return written.reduce(function (chain, a) {
          return chain.then(function () {
            return state.widgets[a.id].upload(function (item, b64) {
              return postToDrive({ action: "upload_written_image", kind: "assignment", student_id: session.student_id, session_token: session.session_token,
                lesson_path: location.pathname.split("/").filter(Boolean).filter(function (p) { return !/\.html?$/i.test(p); }).join("/"),
                attempt_id: state.record.client_id, question_id: a.id, image_id: item.id, data_base64: b64, mime_type: "image/jpeg" });
            }).then(function (r) { if (!r.ok) throw new Error(r.error || "A photo didn't upload."); });
          });
        }, Promise.resolve());
      }

      // Posts state.record. Safe to call again (retry button): same
      // client_id, so the server ignores it if the first try landed.
      function sendRecord() {
        state.syncStatus = "pending";
        state.busy = false;
        render();
        // "Busy" replies (a whole class saving at once) are repeated automatically
        // with the same client_id — never a duplicate — while the page says it is
        // still saving.
        uploadPhotos()
          .then(function () {
            return postToDrive(Object.assign({ action: "upload_submission" }, state.record), function () { state.busy = true; render(); });
          })
          .then(function () {
            state.busy = false; state.syncStatus = "ok";
            Object.keys(state.widgets).forEach(function (k) { state.widgets[k].clear(); });   // delivered: drop the local photo draft
            state.widgets = {}; render();
          })
          .catch(function (err) {
            state.busy = false;
            state.syncStatus = (err && err.message === "not-configured") ? "not-configured" : "failed";
            render();
          });
      }

      function renderResult() {
        var pct = state.total ? Math.round((state.score / state.total) * 100) : 0;
        var children = [
          el("span", { class: "tick-br" }),
          el("span", { class: "tick-bl" }),
          el("div", { class: "qz-summary__score" }, [state.score + " / " + state.total]),
          el("div", { class: "qz-summary__label" }, [pct + "% correct \u00b7 " + session.student_name]),
        ];
        if (state.syncStatus === "not-configured") {
          children.push(el("div", { class: "qz-error" }, [
            "Saved on this device. Result delivery isn't fully set up yet \u2014 let your instructor know.",
          ]));
        } else if (state.syncStatus === "failed") {
          children.push(el("div", { class: "qz-error" }, [
            "Saved on this device, but couldn't reach the server just now. It'll still be here if you check back \u2014 consider letting your instructor know just in case.",
          ]));
        }
        if (state.syncStatus === "pending") {
          children.push(el("div", { class: "qz-progress" }, [state.busy ? "Still saving \u2014 lots of submissions are coming in. Please keep this page open\u2026" : "Saving your submission\u2026"]));
        }
        if (state.syncStatus === "failed") {
          var resendBtn = el("button", { class: "qz-next", type: "button" }, ["Retry sending"]);
          resendBtn.addEventListener("click", function () { sendRecord(); });
          children.push(resendBtn);
        }
        // Each attempt is its own new row on the Submissions sheet (Code.gs
        // appends a row per new client_id, never overwrites) — retaking isn't
        // blocked, so this is just giving that an actual button instead of
        // forcing a page reload to get back to a blank form.
        children.push(el("button", { class: "qz-retry", type: "button" }, ["Submit another attempt"]));

        var summary = el("div", { class: "qz-summary frame" }, children);
        summary.querySelector(".qz-retry").addEventListener("click", function () {
          state.submitted = false;
          state.score = 0;
          state.total = 0;
          state.answers = [];
          state.record = null;
          state.syncStatus = null;
          Object.keys(state.widgets).forEach(function (k) { state.widgets[k].clear(); });
          state.widgets = {};
          render();
        });
        root.appendChild(summary);
      }
    }

    function startAssignment(session) {
      var uiMode = mode === "both" ? "url" : mode; // for "both", start on the link tab
      var submitting = false; // blocks a second click/tap while one is in flight

      render();

      function render() {
        root.innerHTML = "";

        var errorMsg = el("div", { class: "qz-error" });

        var fieldsWrap = el("div", {});
        var textArea, urlInput, fileInput, noteArea;

        function buildTextField() {
          textArea = el("textarea", { class: "qz-textarea", rows: "10", placeholder: "Paste your assignment text here\u2026", required: "required" });
          return el("div", { class: "qz-field" }, [textArea]);
        }
        function buildUrlField() {
          urlInput = el("input", { class: "qz-input", type: "url", placeholder: "https:// link to your work (Docs, Drive, GitHub, etc.)", required: "required" });
          noteArea = el("textarea", { class: "qz-textarea", rows: "4", placeholder: "Notes (optional)" });
          return el("div", {}, [
            el("div", { class: "qz-field" }, [urlInput]),
            el("div", { class: "qz-field" }, [noteArea]),
          ]);
        }
        function buildFileField() {
          fileInput = el("input", { class: "qz-input", type: "file", required: "required" });
          noteArea = el("textarea", { class: "qz-textarea", rows: "4", placeholder: "Notes (optional)" });
          return el("div", {}, [
            el("div", { class: "qz-field" }, [fileInput]),
            el("div", { class: "qz-field" }, [noteArea]),
          ]);
        }

        function renderFields() {
          fieldsWrap.innerHTML = "";
          if (uiMode === "text") fieldsWrap.appendChild(buildTextField());
          else if (uiMode === "url") fieldsWrap.appendChild(buildUrlField());
          else if (uiMode === "file") fieldsWrap.appendChild(buildFileField());
        }
        renderFields();

        var toggle = null;
        if (mode === "both") {
          var linkBtn = el("button", { class: "qz-mode-btn" + (uiMode === "url" ? " active" : ""), type: "button" }, ["Submit a link"]);
          var fileBtn = el("button", { class: "qz-mode-btn" + (uiMode === "file" ? " active" : ""), type: "button" }, ["Upload a file"]);
          linkBtn.addEventListener("click", function () { uiMode = "url"; render(); });
          fileBtn.addEventListener("click", function () { uiMode = "file"; render(); });
          toggle = el("div", { class: "qz-mode-toggle" }, [linkBtn, fileBtn]);
        }

        var submitBtn = el("button", { class: "qz-next", type: "button" }, ["Submit assignment \u2192"]);
        submitBtn.addEventListener("click", function () { onSubmit(submitBtn); });

        function onSubmit(btn) {
          if (submitting) return;
          if (uiMode === "text") {
            var text = textArea.value.trim();
            if (!text) {
              errorMsg.textContent = "Please paste your assignment text.";
              return;
            }
            submitRecord({ submission_type: "text", text: text });
            return;
          }

          if (uiMode === "url") {
            var url = urlInput.value.trim();
            if (!url) {
              errorMsg.textContent = "Please paste a link to your work.";
              return;
            }
            submitRecord({ submission_type: "url", url: url, note: noteArea.value.trim() || null });
            return;
          }

          if (uiMode === "file") {
            var file = fileInput.files && fileInput.files[0];
            if (!file) {
              errorMsg.textContent = "Please choose a file.";
              return;
            }
            if (file.size > MAX_FILE_BYTES) {
              errorMsg.textContent = "That file is larger than 15MB \u2014 use a link instead (Drive/Docs share link).";
              return;
            }
            btn.disabled = true;
            btn.textContent = "Uploading\u2026";
            fileToBase64(file).then(function (base64) {
              submitRecord({
                submission_type: "file",
                filename: file.name,
                mime_type: file.type || "application/octet-stream",
                data_base64: base64,
                note: noteArea.value.trim() || null,
              });
            }).catch(function (err) {
              btn.disabled = false;
              btn.textContent = "Submit assignment \u2192";
              errorMsg.textContent = err.message || "Could not read that file.";
            });
            return;
          }

          function submitRecord(extra) {
            submitting = true;
            btn.disabled = true;
            btn.textContent = "Submitting\u2026";
            var now = new Date();
            var base = {
              type: "assignment",
              client_id: newId(),
              subject: subject,
              lesson: lesson,
              student_id: session.student_id,
              name: session.student_name,
              email: null,
              date: isoDate(now),
              submitted_time: now.toISOString(),
            };
            var record = Object.assign({}, base, extra);

            queueSubmission(record);
            saveLastSubmission(subject, lesson, record);
            sendPlain(record, function () { btn.textContent = "Still saving\u2026 keep this page open"; });
          }
        }

        var card = el("div", { class: "qz-card frame" }, [
          el("span", { class: "tick-br" }),
          el("span", { class: "tick-bl" }),
          toggle,
          el("div", { class: "qz-verdict" }, [
            el("span", { class: "qz-verdict__explain" }, ["Signed in as " + session.student_name]),
          ]),
          fieldsWrap,
          errorMsg,
          el("div", { class: "qz-actions" }, [submitBtn]),
        ]);

        root.appendChild(card);
      }

      // Posts a text/url/file record. Re-callable for the same record (retry
      // button) — the server drops it if the first try already landed.
      function sendPlain(record, onBusy) {
        postToDrive(Object.assign({ action: "upload_submission" }, record), onBusy)
          .then(function () { submitting = false; renderConfirmation(true, true, true, record); })
          .catch(function (err) {
            submitting = false;
            var configured = err.message !== "not-configured";
            renderConfirmation(true, false, configured, record);
          });
      }

      function renderConfirmation(ok, synced, driveAttempted, record) {
        root.innerHTML = "";
        var label;
        if (!ok) {
          label = "Something went wrong saving your submission.";
        } else if (synced) {
          label = "Received \u2014 thank you.";
        } else if (driveAttempted === false) {
          label = "Saved on this device. Submission delivery isn't fully set up yet \u2014 let your instructor know.";
        } else {
          label = "Saved on this device, but couldn't reach the server just now. It'll still be here if you check back \u2014 consider letting your instructor know just in case.";
        }
        var summaryChildren = [
          el("span", { class: "tick-br" }),
          el("span", { class: "tick-bl" }),
          el("div", { class: "qz-summary__label" }, [label]),
        ];
        if (!synced && driveAttempted !== false && record) {
          var resendBtn = el("button", { class: "qz-next", type: "button" }, ["Retry sending"]);
          resendBtn.addEventListener("click", function () {
            resendBtn.disabled = true;
            resendBtn.textContent = "Sending\u2026";
            submitting = true;
            sendPlain(record, function () { resendBtn.textContent = "Still saving\u2026 keep this page open"; });
          });
          summaryChildren.push(resendBtn);
        }
        summaryChildren.push(el("button", { class: "qz-retry", type: "button" }, ["Submit another"]));
        var summary = el("div", { class: "qz-summary frame" }, summaryChildren);
        // Same "each attempt is a new row" story as the graded flow above —
        // every new submission (new client_id) adds a row, so resubmitting
        // (a new text paste, a corrected link, a replacement file) never
        // overwrites the first one.
        summary.querySelector(".qz-retry").addEventListener("click", render);
        root.appendChild(summary);
      }
    }
  }

  window.AssignEngine = { mount: mount };
})();
