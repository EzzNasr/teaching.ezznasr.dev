#!/usr/bin/env python3
"""
assignment_tab.py — Tab 2: Assignment Maker.

Works on a lesson that already exists (created via the Quiz Maker tab).
Lets you write a longer assignment description and pick how students
submit: paste text, a link, a file upload, either link-or-file, or a
set of auto-graded questions (MCQ/True-False/Matching — the dialogs for
those live in modules/common.py, shared with the Quiz Maker tab so
building a question feels the same in both places).

File uploads go through the Drive bridge (Apps Script Web App) configured
at the top of the window — students only ever see this site, never
drive.google.com. See apps_script/Code.gs for the server side.
"""

import json
import os
import re
import tkinter as tk
from tkinter import ttk, messagebox

from modules import common
from modules.common import (
    GRADED_BULK_HELP,
    parse_bulk_graded_questions,
    MCQItemDialog,
    TrueFalseItemDialog,
    MatchItemDialog,
    GradedBulkDialog,
)

class AssignmentTab(ttk.Frame):
    def __init__(self, parent, site_root_var, status_var):
        super().__init__(parent)
        self.site_root_var = site_root_var
        self.status_var = status_var
        self._group_map = {}
        self._build_form()

    def _build_form(self):
        pad = {"padx": 10, "pady": 6}

        pick_frame = tk.LabelFrame(self, text="Lesson")
        pick_frame.pack(fill="x", **pad)

        row1 = tk.Frame(pick_frame)
        row1.pack(fill="x", padx=8, pady=4)
        tk.Label(row1, text="Subject:", width=14, anchor="w").pack(side="left")
        self.subject_var = tk.StringVar(value=common.SUBJECTS[0][1])
        subject_combo = ttk.Combobox(row1, textvariable=self.subject_var, state="readonly",
                                      values=[label for _, label in common.SUBJECTS])
        subject_combo.pack(side="left", fill="x", expand=True)
        subject_combo.bind("<<ComboboxSelected>>", lambda e: self._refresh_groups())

        row1b = tk.Frame(pick_frame)
        row1b.pack(fill="x", padx=8, pady=4)
        tk.Label(row1b, text="Group:", width=14, anchor="w").pack(side="left")
        self.group_var = tk.StringVar()
        self.group_combo = ttk.Combobox(row1b, textvariable=self.group_var, state="readonly", values=[])
        self.group_combo.pack(side="left", fill="x", expand=True)
        self.group_combo.bind("<<ComboboxSelected>>", lambda e: self._refresh_lessons())
        tk.Label(pick_frame,
                 text="Where the lesson lives inside the subject \u2014 e.g. \u201c(subject root)\u201d for flat "
                      "subjects, or a nested folder like \u201cBaccalaureate / Grade 1 Secondary\u201d. Must "
                      "match what the lesson was actually generated under (Quiz Maker tab) or it won't show "
                      "up below.",
                 fg="gray30", font=("TkDefaultFont", 8), justify="left", wraplength=560).pack(anchor="w", padx=8, pady=(0, 6))

        row2 = tk.Frame(pick_frame)
        row2.pack(fill="x", padx=8, pady=4)
        tk.Label(row2, text="Lesson:", width=14, anchor="w").pack(side="left")
        self.lesson_var = tk.StringVar()
        self.lesson_combo = ttk.Combobox(row2, textvariable=self.lesson_var, state="readonly", values=[])
        self.lesson_combo.pack(side="left", fill="x", expand=True)
        tk.Button(row2, text="Refresh", command=self._refresh_lessons).pack(side="left", padx=6)
        tk.Button(row2, text="Load current settings", command=self._load_current).pack(side="left")

        video_frame = tk.LabelFrame(self, text="Video")
        video_frame.pack(fill="x", **pad)
        vrow = tk.Frame(video_frame)
        vrow.pack(fill="x", padx=8, pady=4)
        tk.Label(vrow, text="Video URL:", width=14, anchor="w").pack(side="left")
        self.video_url_var = tk.StringVar()
        tk.Entry(vrow, textvariable=self.video_url_var).pack(side="left", fill="x", expand=True)
        tk.Button(vrow, text="Update video", command=self._update_video).pack(side="left", padx=6)
        tk.Label(video_frame,
                 text="Paste any YouTube link (watch/share/shorts URL, or an embed URL directly) — it's "
                      "converted automatically. Leave blank and click Update video to remove the video and "
                      "go back to a placeholder box. This only touches the video; it doesn't affect the "
                      "assignment prompt or submission mode below.",
                 fg="gray30", font=("TkDefaultFont", 8), justify="left", wraplength=560).pack(anchor="w", padx=8, pady=(0, 6))

        prompt_frame = tk.LabelFrame(self, text="Assignment description")
        prompt_frame.pack(fill="both", expand=True, **pad)
        tk.Label(prompt_frame, text="This is shown to students on the assignment page. Multiple paragraphs are fine.",
                 fg="gray30", font=("TkDefaultFont", 8)).pack(anchor="w", padx=8, pady=(6, 0))
        self.prompt_text = tk.Text(prompt_frame, height=10, wrap="word",
                                    undo=True, autoseparators=True, maxundo=-1)
        self.prompt_text.pack(fill="both", expand=True, padx=8, pady=8)

        mode_frame = tk.LabelFrame(self, text="How students submit")
        mode_frame.pack(fill="x", **pad)
        row3 = tk.Frame(mode_frame)
        row3.pack(fill="x", padx=8, pady=6)
        tk.Label(row3, text="Submission type:", width=14, anchor="w").pack(side="left")
        self.mode_label_var = tk.StringVar(value=common.SUBMIT_MODES[0][1])
        mode_combo = ttk.Combobox(row3, textvariable=self.mode_label_var, state="readonly",
                                   values=[label for _, label in common.SUBMIT_MODES])
        mode_combo.pack(side="left", fill="x", expand=True)
        tk.Label(mode_frame,
                 text="Paste text: works with no setup. Link/File/Both: requires the Drive bridge "
                      "configured above (files upload to your Drive folder \u2014 students never see it). "
                      "Graded questions: auto-marked MCQ/True-False/Matching, scored the instant the "
                      "student submits \u2014 fill in the Graded questions section below.",
                 fg="gray30", font=("TkDefaultFont", 8), justify="left", wraplength=560).pack(anchor="w", padx=8, pady=(0, 6))

        graded_frame = tk.LabelFrame(self, text="Graded questions (only used when Submission type = Graded questions)")
        graded_frame.pack(fill="both", expand=True, **pad)

        graded_btn_row = tk.Frame(graded_frame)
        graded_btn_row.pack(fill="x", padx=8, pady=6)
        tk.Button(graded_btn_row, text="+ Multiple choice", command=self._add_mcq).pack(side="left")
        tk.Button(graded_btn_row, text="+ True/False", command=self._add_truefalse).pack(side="left", padx=6)
        tk.Button(graded_btn_row, text="+ Matching", command=self._add_match).pack(side="left")
        tk.Button(graded_btn_row, text="+ Bulk paste...", command=self._bulk_add_graded).pack(side="left", padx=6)
        tk.Button(graded_btn_row, text="Edit selected", command=self._edit_graded).pack(side="left", padx=6)
        tk.Button(graded_btn_row, text="Remove selected", command=self._remove_graded).pack(side="left")

        graded_list_frame = tk.Frame(graded_frame)
        graded_list_frame.pack(fill="both", expand=True, padx=8, pady=(0, 4))
        self.graded_listbox = tk.Listbox(graded_list_frame)
        self.graded_listbox.pack(side="left", fill="both", expand=True)
        graded_scrollbar = tk.Scrollbar(graded_list_frame, command=self.graded_listbox.yview)
        graded_scrollbar.pack(side="right", fill="y")
        self.graded_listbox.config(yscrollcommand=graded_scrollbar.set)
        self.graded_listbox.bind("<Double-Button-1>", lambda e: self._edit_graded())

        tk.Label(graded_frame,
                 text="Multiple choice: check every correct box (checking more than one makes it a "
                      "\u201cselect all that apply\u201d question). Matching: type each row's term and its "
                      "correct match \u2014 students see a dropdown per row built from every row's answers. "
                      "Double-click a question below to edit it. Note: existing questions aren't reloaded by "
                      "\u201cLoad current settings\u201d (only the generated JSON is stored on the page) \u2014 "
                      "keep this list open if you'll need to edit it later, or re-add from a saved bulk-paste "
                      "copy.",
                 fg="gray30", font=("TkDefaultFont", 8), justify="left", wraplength=700).pack(anchor="w", padx=8, pady=(0, 6))

        gen_row = tk.Frame(self)
        gen_row.pack(fill="x", padx=10, pady=12)
        tk.Button(gen_row, text="Update assignment page", command=self._update,
                  font=("TkDefaultFont", 10, "bold"), height=2).pack(fill="x")

        self.graded_items = []
        self._refresh_groups()

    # -- graded questions list ---------------------------------------------

    def _refresh_graded_listbox(self):
        self.graded_listbox.delete(0, "end")
        labels = {"mcq": "MCQ", "truefalse": "T/F", "match": "Match"}
        for i, item in enumerate(self.graded_items):
            preview = item["prompt"][:70].replace("\n", " ")
            self.graded_listbox.insert("end", "{:>2}. [{}] {}".format(i + 1, labels.get(item["type"], "?"), preview))

    def _add_mcq(self):
        dlg = MCQItemDialog(self)
        self.wait_window(dlg)
        if dlg.result:
            self.graded_items.append(dlg.result)
            self._refresh_graded_listbox()

    def _add_truefalse(self):
        dlg = TrueFalseItemDialog(self)
        self.wait_window(dlg)
        if dlg.result:
            self.graded_items.append(dlg.result)
            self._refresh_graded_listbox()

    def _add_match(self):
        dlg = MatchItemDialog(self)
        self.wait_window(dlg)
        if dlg.result:
            self.graded_items.append(dlg.result)
            self._refresh_graded_listbox()

    def _bulk_add_graded(self):
        dlg = GradedBulkDialog(self)
        self.wait_window(dlg)
        if dlg.result:
            self.graded_items.extend(dlg.result)
            self._refresh_graded_listbox()
            self.status_var.set("Added {} question(s) from bulk paste.".format(len(dlg.result)))

    def _edit_graded(self):
        sel = self.graded_listbox.curselection()
        if not sel:
            messagebox.showinfo("No selection", "Select a question to edit.")
            return
        idx = sel[0]
        item = self.graded_items[idx]
        dialog_cls = {"mcq": MCQItemDialog, "truefalse": TrueFalseItemDialog, "match": MatchItemDialog}[item["type"]]
        dlg = dialog_cls(self, existing=item)
        self.wait_window(dlg)
        if dlg.result:
            self.graded_items[idx] = dlg.result
            self._refresh_graded_listbox()

    def _remove_graded(self):
        sel = self.graded_listbox.curselection()
        if not sel:
            messagebox.showinfo("No selection", "Select a question to remove.")
            return
        del self.graded_items[sel[0]]
        self._refresh_graded_listbox()

    # -- helpers ----------------------------------------------------------

    def _subject_slug(self):
        label = self.subject_var.get()
        for slug, name in common.SUBJECTS:
            if name == label:
                return slug
        return common.slugify(label)

    def _mode_slug(self):
        label = self.mode_label_var.get()
        for slug, name in common.SUBMIT_MODES:
            if name == label:
                return slug
        return "text"

    def _refresh_groups(self):
        site_root = self.site_root_var.get().strip()
        subject_slug = self._subject_slug()
        relpaths = common.list_lesson_groups(site_root, subject_slug) if site_root else []
        if not relpaths:
            relpaths = [""]
        self._group_map = {common.group_display_name(rp): rp for rp in relpaths}
        display_values = list(self._group_map.keys())
        self.group_combo["values"] = display_values
        if display_values and self.group_var.get() not in display_values:
            self.group_var.set(display_values[0])
        elif not display_values:
            self.group_var.set("")
        self._refresh_lessons()

    def _group_relpath(self):
        return self._group_map.get(self.group_var.get(), "")

    def _lesson_dir(self):
        site_root = self.site_root_var.get().strip()
        subject_slug = self._subject_slug()
        group_relpath = self._group_relpath()
        lesson_slug = self.lesson_var.get().strip()
        if not (site_root and lesson_slug):
            return None
        return os.path.join(common.group_dir(site_root, subject_slug, group_relpath), lesson_slug)

    def _refresh_lessons(self):
        site_root = self.site_root_var.get().strip()
        subject_slug = self._subject_slug()
        group_relpath = self._group_relpath()
        lessons = common.list_existing_lessons(site_root, subject_slug, group_relpath) if site_root else []
        self.lesson_combo["values"] = lessons
        if lessons and self.lesson_var.get() not in lessons:
            self.lesson_var.set(lessons[0])
        elif not lessons:
            self.lesson_var.set("")

    def _load_current(self):
        lesson_dir = self._lesson_dir()
        if not lesson_dir or not os.path.isdir(lesson_dir):
            messagebox.showinfo("No lesson selected", "Pick a subject and lesson first.")
            return

        index_path = os.path.join(lesson_dir, "index.html")
        if os.path.exists(index_path):
            with open(index_path, "r", encoding="utf-8") as f:
                index_content = f.read()
            slot_match = self._MEDIA_SLOT_RE.search(index_content)
            if slot_match:
                iframe_match = re.search(r'<iframe src="([^"]+)"', slot_match.group(2))
                self.video_url_var.set(iframe_match.group(1) if iframe_match else "")

        assignment_path = os.path.join(lesson_dir, "assignment.html")
        if os.path.exists(assignment_path):
            with open(assignment_path, "r", encoding="utf-8") as f:
                content = f.read()
            prompt_match = re.search(r'<p class="lede">(.*?)</p>', content, re.DOTALL)
            if prompt_match:
                prompt = prompt_match.group(1).strip()
                self.prompt_text.delete("1.0", "end")
                self.prompt_text.insert("1.0", prompt)
            mode_match = re.search(r'data-mode="([a-z]+)"', content)
            if mode_match:
                mode_slug = mode_match.group(1)
                for slug, label in common.SUBMIT_MODES:
                    if slug == mode_slug:
                        self.mode_label_var.set(label)
                        break
            self.graded_items = []
            if mode_match and mode_match.group(1) == "graded":
                q_match = re.search(r'id="assign-questions">\s*(\{.*?\})\s*</script>', content, re.DOTALL)
                if q_match:
                    try:
                        loaded = json.loads(q_match.group(1)).get("items", [])
                        # Strip the generation-time "id" field — it's reassigned
                        # fresh on every Update, so it's not part of the editable shape.
                        self.graded_items = [{k: v for k, v in item.items() if k != "id"} for item in loaded]
                    except Exception:
                        self.graded_items = []
            self._refresh_graded_listbox()
            self.status_var.set("Loaded current assignment settings for " + self.lesson_var.get())
        else:
            self.prompt_text.delete("1.0", "end")
            self.prompt_text.insert("1.0", "Paste your completed assignment below.")
            self.mode_label_var.set(common.SUBMIT_MODES[0][1])
            self.graded_items = []
            self._refresh_graded_listbox()
            self.status_var.set("No assignment.html yet for this lesson — fill in the form and click Update.")

    _MEDIA_SLOT_RE = re.compile(r'(<div class="media-slot">)(.*?)(</div>)', re.DOTALL)
    _VIDEO_PLACEHOLDER = "Video placeholder &mdash; add a YouTube embed URL to replace this box."

    @staticmethod
    def _normalize_video_url(url):
        """Accept whatever a person is likely to paste — a normal watch
        link, a youtu.be share link, a Shorts link, or an already-correct
        embed URL — and return a proper https://www.youtube.com/embed/ID
        URL. Anything that isn't recognizably YouTube (e.g. a Vimeo embed
        URL someone pastes on purpose) is passed through unchanged, since
        the iframe wrapper works with any embeddable video URL, not just
        YouTube's."""
        url = url.strip()
        if not url:
            return ""

        if re.search(r"youtube\.com/embed/", url) or re.search(r"player\.vimeo\.com", url):
            return url  # already an embed URL (or a non-YouTube embed) — leave as-is

        m = re.search(r"youtu\.be/([A-Za-z0-9_-]{6,})", url)
        if not m:
            m = re.search(r"youtube\.com/shorts/([A-Za-z0-9_-]{6,})", url)
        if not m:
            m = re.search(r"[?&]v=([A-Za-z0-9_-]{6,})", url)
        if m:
            video_id = m.group(1)
            return "https://www.youtube.com/embed/" + video_id

        return url  # not recognized as YouTube — pass through unchanged

    def _update_video(self):
        lesson_dir = self._lesson_dir()
        if not lesson_dir or not os.path.isdir(lesson_dir):
            messagebox.showerror("No lesson selected", "Pick a subject and lesson first (generate it in the "
                                                         "Quiz Maker tab if it doesn't exist yet).")
            return

        index_path = os.path.join(lesson_dir, "index.html")
        if not os.path.exists(index_path):
            messagebox.showerror("No lesson page found", "This lesson has no index.html to update.")
            return

        with open(index_path, "r", encoding="utf-8") as f:
            content = f.read()

        if not self._MEDIA_SLOT_RE.search(content):
            messagebox.showerror("Couldn't find the video area",
                                  "This lesson's index.html doesn't have the expected media-slot section — "
                                  "it may have been hand-edited or use an older template.")
            return

        raw_url = self.video_url_var.get().strip()
        embed_url = self._normalize_video_url(raw_url)

        if embed_url:
            lesson_title = self._lesson_title(lesson_dir)
            video_block = '<iframe src="{}" title="{}" allowfullscreen></iframe>'.format(embed_url, lesson_title)
        else:
            video_block = self._VIDEO_PLACEHOLDER

        new_content = self._MEDIA_SLOT_RE.sub(
            lambda m: m.group(1) + "\n      " + video_block + "\n    " + m.group(3), content, count=1)

        with open(index_path, "w", encoding="utf-8") as f:
            f.write(new_content)

        if embed_url and embed_url != raw_url:
            self.video_url_var.set(embed_url)

        self.status_var.set("Updated video for {}/{}".format(self._subject_slug(), self.lesson_var.get()))
        if embed_url:
            messagebox.showinfo("Done", "Video embed updated.")
        else:
            messagebox.showinfo("Done", "Video removed — back to a placeholder box.")

    def _lesson_title(self, lesson_dir):
        index_path = os.path.join(lesson_dir, "index.html")
        if os.path.exists(index_path):
            with open(index_path, "r", encoding="utf-8") as f:
                content = f.read()
            m = re.search(r"<h1>(.*?)</h1>", content, re.DOTALL)
            if m:
                # strip any inner tags like <strong>
                return re.sub(r"<[^>]+>", "", m.group(1)).strip()
        return self.lesson_var.get().replace("-", " ").title()

    # -- update -------------------------------------------------------------

    def _update(self):
        site_root = self.site_root_var.get().strip()
        if not site_root or not os.path.isdir(site_root):
            messagebox.showerror("Site location missing", "Pick a valid site root folder first (top of the window).")
            return

        lesson_dir = self._lesson_dir()
        if not lesson_dir or not os.path.isdir(lesson_dir):
            messagebox.showerror("No lesson selected", "Pick a subject and lesson first (generate it in the "
                                                         "Quiz Maker tab if it doesn't exist yet).")
            return

        mode_slug = self._mode_slug()
        if mode_slug != "text":
            drive_cfg = common.get_drive_config(common.load_config())
            if not drive_cfg["web_app_url"]:
                if not messagebox.askyesno(
                        "Drive bridge not configured",
                        "This submission type needs the Drive bridge Web App URL (set it at the top of the "
                        "window) or student links/files won't be able to reach your Drive.\n\n"
                        "Continue anyway and set it up later?"):
                    return

        prompt = self.prompt_text.get("1.0", "end").strip()
        if not prompt:
            messagebox.showerror("Missing description", "Enter an assignment description.")
            return

        graded_items_out = []
        if mode_slug == "graded":
            if not self.graded_items:
                messagebox.showerror(
                    "No graded questions",
                    "Submission type is \u201cGraded questions\u201d, but no questions have been added yet. "
                    "Use the + Multiple choice / + True/False / + Matching / + Bulk paste buttons below "
                    "to add some first.")
                return
            graded_items_out = [dict(item, id="g" + str(i + 1)) for i, item in enumerate(self.graded_items)]

        subject_slug = self._subject_slug()
        group_relpath = self._group_relpath()
        lesson_slug = self.lesson_var.get().strip()
        lesson_title = self._lesson_title(lesson_dir)
        location_label = common.lesson_url_path(subject_slug, group_relpath, lesson_slug)
        track_class = common.track_class_for_group(subject_slug, group_relpath)

        assignment_html = common.load_template("assignment.html")
        assignment_html = (assignment_html
                            .replace("{{SUBJECT_SLUG}}", subject_slug)
                            .replace("{{LESSON_SLUG}}", lesson_slug)
                            .replace("{{LESSON_TITLE}}", lesson_title)
                            .replace("{{SUBMIT_MODE}}", mode_slug)
                            .replace("{{ASSIGN_PROMPT}}", prompt)
                            .replace("{{TRACK_CLASS}}", track_class)
                            .replace("{{LESSON_URL_PATH}}", location_label)
                            .replace("{{ASSIGN_QUESTIONS_JSON}}", json.dumps({"items": graded_items_out})))
        with open(os.path.join(lesson_dir, "assignment.html"), "w", encoding="utf-8") as f:
            f.write(assignment_html)

        # Make sure the lesson's index.html actually links to the assignment
        # page (in case this lesson was generated with "include assignment"
        # unchecked, or this is the first time an assignment is being added).
        self._ensure_assignment_link(lesson_dir, location_label)

        self.status_var.set("Updated assignment.html for {}/{} (mode: {})".format(
            location_label, lesson_slug, mode_slug))
        messagebox.showinfo("Done", "assignment.html updated for {}/{}.\n\nSubmission mode: {}".format(
            subject_slug, lesson_slug, self.mode_label_var.get()))

    def _ensure_assignment_link(self, lesson_dir, location_label):
        index_path = os.path.join(lesson_dir, "index.html")
        if not os.path.exists(index_path):
            return
        with open(index_path, "r", encoding="utf-8") as f:
            content = f.read()
        if "assignment.html" in content:
            return
        link_block = (
            '      <a class="lesson-link frame" href="/{}/assignment.html">\n'
            '        <div class="ll-title">Assignment</div>\n'
            '        <div class="ll-desc">Submit your work</div>\n'
            '        <span class="ll-go">Submit</span>\n'
            '      </a>\n'
        ).format(location_label)
        marker = "{{ASSIGNMENT_LINK_BLOCK}}"
        if marker in content:
            content = content.replace(marker, link_block)
        else:
            # marker was already substituted at generation time (with "") —
            # splice the link back in right before the attachments block.
            content = re.sub(
                r'(\n    </div>\n\n    <div class="attachments")',
                "\n" + link_block + r'    </div>\n\n    <div class="attachments"',
                content, count=1)
        with open(index_path, "w", encoding="utf-8") as f:
            f.write(content)
